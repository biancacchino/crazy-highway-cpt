package javier;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Driver extends Sprite {
	
	private static final Image EXPLOSION_PIC = new Image("file:resources/images/explosion.png");
	private ImageView explosion = new ImageView(EXPLOSION_PIC);
	
	private boolean isDead = false;

	public Driver(Image i) {
		super(i);
		super.getChildren().addAll(explosion);
		
		
		explosion.setVisible(false);
		explosion.setLayoutX(10);
		explosion.setLayoutY(5);
	}

	public void driveLeft(double time) {
		setVelocityX(-250);
		update(time);
		setVelocityX(0);
		
		if (getPositionX() <= 10) {
			setPositionX(10);
		}
	}
	
	public void driveRight(double time) {
		setVelocityX(250);
		update(time);
		setVelocityX(0);
		
		if (getPositionX() > 370) {
			setPositionX(370);
		}
	}
	
	public Bullet shoot() {
		Bullet b = new Bullet();
		b.setPositionX(getPositionX() + getWidth()/2 - b.getWidth());
		b.setPositionY(getPositionY());
		b.setVelocityY(-500);
		return b;
	}

	public void kill() {
		isDead = true;
		explosion.setVisible(true);
	}
	
	public boolean isDead() {
		return isDead;
	}
	
	public void revive() {
		isDead = false;
		explosion.setVisible(false);
	}
	
}
