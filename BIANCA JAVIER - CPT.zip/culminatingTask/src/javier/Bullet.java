package javier;

import javafx.scene.image.Image;

public class Bullet extends Sprite {

	private static final Image BULLET_IMAGE = new Image("file:resources/images/userBullet.png");
	private boolean isDead = false;
	
	public Bullet() {
		super(BULLET_IMAGE);
	}
	
	
	/**
	 * Reports if the bullet is dead (and therefore is not involved in collisions)
	 */
	public boolean isDead() {
		return isDead;
	}
	
	/**
	 * Tells if the bullet can be cleaned up because it is dead
	 */
	public boolean isReadyForCleanUp() {
		return isDead;
	}
	
	/**
	 * Kill the bullet immediately
	 */
	public void kill() {
		isDead = true;
	}
	
    public boolean intersect(Sprite s) {
        if (isDead) {
            return false;
        } else {
            if (s instanceof OtherCar) {
                OtherCar otherCar = (OtherCar) s;
                otherCar.takeDamage(); // Inflict damage
                kill(); // Kill the bullet upon hitting
                return true;
            } else {
                return super.intersect(s);
            }
        }
    }
        
}