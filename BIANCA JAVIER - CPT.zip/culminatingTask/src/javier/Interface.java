package javier;

import java.util.HashSet;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Background;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class Interface extends Application {

	//Window size constants
	public final static int GAME_WIDTH = 450;
	public final static int GAME_HEIGHT = 800;

	//Game states
	public static final int TITLE_SCREEN = 0;
	public static final int PLAYING = 1;
	public static final int GAME_OVER = 2;
	
	private int gameState = TITLE_SCREEN;

	// used to track keys as they are pressed/released.
	private final HashSet keyboard = new HashSet();

	private GameTimer gameTimer = new GameTimer(time -> updateGame(time));
	private double newCarTimer = 1;
	
	// Score
	private int score = 0;
	private double scoreTimer = 0;
	
	
	private Group bullets = new Group();
	private double gunCoolDown = 0.25;
	
	private Sprite[] background = {
			new Sprite (new Image("file:resources/images/background.png", GAME_WIDTH, 0, true, false)),
			new Sprite (new Image("file:resources/images/background.png", GAME_WIDTH, 0, true, false))
	};

	private Group backgroundDisplay = new Group (background[0], background[1]);
	
	private Driver player = new Driver(new Image("file:resources/images/plane.png"));
	
	private Group otherCars = new Group();
	//Interface elements for game screens
	private Text title = new Text("1942 the Game");
	private Text subtitle = new Text("Press Space to Begin");
	private Text endTitle = new Text ("GAME \nOVER");
	private Text endSubtitle = new Text("Press space to play again\nESC to quit");
	private Text scoreText = new Text("Score: " + score);
	private Text endScore = new Text("");
	
	
	//Game Screen Groups
	private Group[] gameScreens = {
			new Group(title, subtitle),								
			new Group(backgroundDisplay, player, otherCars, bullets, scoreText),
			new Group(endTitle, endSubtitle, endScore)
	};
	
	
	public Interface() {
		newGame();
		
	}
	
	public void start(Stage primaryStage) throws Exception {
		Group root = new Group();
		Scene gameScene = new Scene(root, GAME_WIDTH, GAME_HEIGHT, Color.DARKGRAY);
		primaryStage.setScene(gameScene);
		primaryStage.setResizable(false);
		primaryStage.setTitle("Bianca's Culminating Task");
		primaryStage.show();
		
		gameScene.setOnKeyPressed(key -> keyPressed(key));
		gameScene.setOnKeyReleased(key -> keyReleased(key));
		root.getChildren().addAll(gameScreens[PLAYING], gameScreens[TITLE_SCREEN], gameScreens[GAME_OVER]);
		gameScreens[TITLE_SCREEN].setVisible(true);
		gameScreens[PLAYING].setVisible(true);
		gameScreens[GAME_OVER].setVisible(false);
		
		//Styling for the Text on Game Screens
		title.setFont(Font.font("ArcadeClassic", 50));
		title.setFill(Color.RED);
		title.setEffect(new DropShadow());
		title.setStroke(Color.WHITE);
		title.setStrokeWidth(2);
		title.setLayoutX(GAME_WIDTH/2 - title.getLayoutBounds().getWidth()/2);
		title.setLayoutY(300);
		
		subtitle.setFont(Font.font("ArcadeClassic", 30));
		subtitle.setFill(Color.RED);
		subtitle.setEffect(new DropShadow());
		subtitle.setStroke(Color.WHITE);
		subtitle.setStrokeWidth(2);
		subtitle.setLayoutX(GAME_WIDTH/2 - subtitle.getLayoutBounds().getWidth()/2);
		subtitle.setLayoutY(GAME_HEIGHT/2 + 200);
		
		endTitle.setFont(Font.font("ArcadeClassic", 85));
		endTitle.setFill(Color.RED);
		endTitle.setEffect(new DropShadow());
		endTitle.setStroke(Color.WHITE);
		endTitle.setStrokeWidth(3);
		endTitle.setTextAlignment(TextAlignment.CENTER);
		endTitle.setLayoutX(GAME_WIDTH/2 - endTitle.getLayoutBounds().getWidth()/2);
		endTitle.setLayoutY(GAME_HEIGHT/2 - endTitle.getLayoutBounds().getWidth()/2);
		
		subtitle.setFont(Font.font("ArcadeClassic", 30));
		subtitle.setFill(Color.RED);
		subtitle.setEffect(new DropShadow());
		subtitle.setStroke(Color.WHITE);
		subtitle.setStrokeWidth(2);
		subtitle.setLayoutX(GAME_WIDTH/2 - subtitle.getLayoutBounds().getWidth()/2);
		subtitle.setLayoutY(GAME_HEIGHT/2);
		
		endScore.setFont(Font.font("ArcadeClassic", 30));
		endScore.setFill(Color.BLACK);
		endScore.setEffect(new DropShadow());
		endScore.setStroke(Color.WHITE);
		endScore.setStrokeWidth(2);
		endScore.setTextAlignment(TextAlignment.CENTER);
		endScore.setLayoutX(GAME_WIDTH/2);
		endScore.setLayoutY(GAME_HEIGHT/2);
		
		endSubtitle.setFont(Font.font("ArcadeClassic", 30));
		endSubtitle.setFill(Color.BLUE);
		endSubtitle.setEffect(new DropShadow());
		endSubtitle.setStroke(Color.WHITE);
		endSubtitle.setTextAlignment(TextAlignment.CENTER);
		endSubtitle.setLayoutX(GAME_WIDTH/2 - endSubtitle.getLayoutBounds().getWidth()/2);
		endSubtitle.setLayoutY(GAME_HEIGHT/2 + 200);
		
        scoreText.setFont(Font.font("ArcadeClassic", 40));
        scoreText.setFill(Color.WHITE);
        scoreText.setEffect(new DropShadow());
        scoreText.setStrokeWidth(1);
        scoreText.setLayoutX(15);
        scoreText.setLayoutY(30);
        scoreText.setVisible(false);

	}

	/**
	 * Setup all sprites for a new game
	 */
	public void newGame() {
		// set the backgrounds up for beginning of the game
		scoreText.setVisible(false);
		score = 0;
		scoreText.setText("Score: " + score);
		background[0].setPositionY(0);
		background[1].setPositionY(-background[1].getHeight());
		background[0].setVelocityY(100);
		background[1].setVelocityY(100);
		
		player.setPosition(GAME_WIDTH/2 - player.getWidth()/2, GAME_HEIGHT - 2 * player.getHeight());
		player.setVelocity(0, 0);
		player.revive();
		
		otherCars.getChildren().clear();
		newCarTimer = 1;
		
		bullets.getChildren().clear();
		gunCoolDown = 1;
		
	}
	
	
	/**
	 * Game updates happen as often as the timer can cause an event
	 */
    public void updateGame(double elapsedTime) {
        updateBackground(elapsedTime);
        if (gameState == PLAYING) updatePlayer(elapsedTime);
        updateOtherCars(elapsedTime);
        updateBullets(elapsedTime);

        if (gameState == PLAYING) {
            checkBulletCollisions(elapsedTime);
            checkPlayerCollisions();
            updateScore(elapsedTime);
        }

        cleanUp();

        if (gameState == GAME_OVER) {
            if (otherCars.getChildren().size() == 0) {

                backToTitleScreen();
                
                
            }
        }
    }

/**
 * Scores the player of their time survived, updates score each second
 * @param elapsedTime
 * @param points
 */
     private void updateScore(double elapsedTime) {
     scoreTimer += elapsedTime;
     if (scoreTimer >= 1) {
     	
     	scoreTimer = 1;
     	score += 10; 
         scoreText.setText("Score: " + score);
         scoreTimer = 0;
     }

    }

     /**
      * Checks for player collisions, if player hits, then they die.
      */
	private void checkPlayerCollisions() {
		for (int j = 0; j < otherCars.getChildren().size(); j++) {
			OtherCar car = (OtherCar)otherCars.getChildren().get(j);
			if (car.intersect(player)) {
				car.kill();
				car.setVelocityY(0);
				player.kill();
				gameOver();
				
			}
			
		}
	}

	/**
	 * Checks for bullet collisions, if bullet hit otherCar, then they die.
	 * @param elapsedTime
	 */
	private void checkBulletCollisions (double elapsedTime) {
		for (int i = 0; i < bullets.getChildren().size(); i++) {
			Bullet b = (Bullet)bullets.getChildren().get(i);
			for (int j = 0; j < otherCars.getChildren().size(); j++) {
				OtherCar car = (OtherCar)otherCars.getChildren().get(j);
				car.getType();
				if (car.intersect(b)) {
					car.takeDamage();
					b.kill();
					if (car.isDead()) {
						addScore(10);
					}
				}
			}	
		}
	}
	
	/**
	 * Adds score after killing otherCar
	 * @param points
	 */
	private void addScore(int points) {
		score += points;
		scoreText.setText("Score: " + score);
	}
	/**
	 * Cleans up the cars that went past the screenm
	 */
	public void cleanUp() {
		// Cleanup cars that are ready to be deleted
		for (int i = 0; i < otherCars.getChildren().size(); i++) {
			OtherCar car = (OtherCar)otherCars.getChildren().get(i);
			if (car.isReadyForCleanUp()) {
				otherCars.getChildren().remove(car);
				i--;
			}
		}
		
		// Cleanup bullets that have flown off the screen
		for (int i = 0; i < bullets.getChildren().size(); i++) {
			Bullet b = (Bullet)bullets.getChildren().get(i);
			if (b.isReadyForCleanUp()) {
				bullets.getChildren().remove(b);
				i--;
			}
		}
		
	}
	
	/**
	 * Updates the bullets in real time, giving them an animation
	 * @param elapsedTime
	 */
	public void updateBullets(double elapsedTime) {
		for (int i = 0; i < bullets.getChildren().size(); i++) {
			Bullet b = (Bullet)bullets.getChildren().get(i);
			b.update(elapsedTime);
			
			if (b.getPositionY() < -b.getHeight()) {
				b.kill();
			}
		}
	}
	
	/**
	 * Updates where the enemy cars will spawn and act as obstacles to the player
	 * @param elapsedTime
	 */
	public void updateOtherCars(double elapsedTime) {
		// Add new car
		if (gameState == PLAYING && newCarTimer < 0) {
			OtherCar newCar = new OtherCar();
			newCar.setPosition((335 - newCar.getWidth()) * Math.random() + 80, -newCar.getHeight());
			newCar.setVelocityY(200 * Math.random() + 300);
			otherCars.getChildren().add(newCar);
			
			newCarTimer = Math.random();
		}
		else {
			newCarTimer -= elapsedTime;
		}
		
		for (int i = 0; i < otherCars.getChildren().size(); i++) {
			OtherCar car = (OtherCar)otherCars.getChildren().get(i);
			car.update(elapsedTime);
			
			if (car.getPositionY() > GAME_HEIGHT) {
				car.kill();
			}
		}
	}
	
	
	/**
	 * Move the player left/right depending on keyboard input
	 * @param elapsedTime
	 */
	public void updatePlayer(double elapsedTime) {
		if (keyboard.contains(KeyCode.LEFT)) {
			player.driveLeft(elapsedTime);
		}
		
		if (keyboard.contains(KeyCode.RIGHT)) {
			player.driveRight(elapsedTime);
		}
		
		if (gunCoolDown < 0) {
			if (keyboard.contains(KeyCode.SPACE)) {
				bullets.getChildren().add(player.shoot());
			}
			gunCoolDown = 0.25;
		}
		else {
			gunCoolDown -= elapsedTime;
		}
	}
	
	/**
	 * Updates the background to create road animation.  Moves both images down the window.
	 * When an image passes below the bottom of the window, resets it to the top
	 * 
	 * @param elapsedTime amount of time passed since last update.
	 */
	public void updateBackground(double time) {
		background[0].update(time);
		background[1].update(time);
		
		if (background[0].getPositionY() > GAME_HEIGHT) {
			background[0].setPositionY(background[1].getPositionY() - background[0].getPositionY());
		}
		
		if (background[1].getPositionY() > GAME_HEIGHT) {
			background[1].setPositionY(background[0].getPositionY() - background[1].getPositionY());
		}
	}
	
	
	
	/**
	 * Respond to key press events by checking for the pause key (P),
	 * and starting or stopping the game timer appropriately
	 * 
	 * Other key presses are stored in the "Keyboard" HashSet for polling
	 * during the main game update.
	 * 
	 * @param key KeyEvent program is responding to 
	 */
	public void keyPressed(KeyEvent key) {
		if (gameState == PLAYING) {
			if (!keyboard.contains(KeyCode.P)) {
				if (key.getCode() == KeyCode.P) {
					pause();
				}
			}
		}
		
		if (gameState == TITLE_SCREEN) {
			if (!keyboard.contains(KeyCode.SPACE)) {
				if (key.getCode() == KeyCode.SPACE) {
					startGame();
				}
			}
		}

		if (gameState == GAME_OVER) {
			if (!keyboard.contains(KeyCode.SPACE)) {
				if (key.getCode() == KeyCode.SPACE) {
					backToTitleScreen();
				}
			}
		}
		
		if (!keyboard.contains(KeyCode.ESCAPE)) {
			if (key.getCode() == KeyCode.ESCAPE) {
				Platform.exit();;
			}
		}

		//record this particular key has been pressed:
		keyboard.add(key.getCode());		
	}
	

	/**
	 * Removes a key from the "keyboard" HashSet when it is released
	 * 
	 * @param key KeyEvent that triggered this method call
	 */
	public void keyReleased(KeyEvent key) {
		//remove the record of the key being pressed:
		keyboard.remove(key.getCode());
	}
	

	/**
	 * Starts the game play from the title screen
	 */
	public void startGame() {
		gameScreens[TITLE_SCREEN].setVisible(false);
		gameScreens[GAME_OVER].setVisible(false);
		scoreText.setVisible(true);
		gameState = PLAYING;
		gameTimer.start();
	}
	
	
	/**
	 * Switch the program to a new state when the player loses (by hitting another car).
	 */
	public void gameOver() {
		gameScreens[TITLE_SCREEN].setVisible(false);
		gameScreens[GAME_OVER].setVisible(true);
		gameState = GAME_OVER;
		scoreText.setVisible(false);
		endScore.setText("Your Score: " + score);
		score = 0;
		gameTimer.stop();
	}
	/**
	 * Switch the program to a new state when the player wants to restart
	 */
	public void backToTitleScreen() {
		gameScreens[TITLE_SCREEN].setVisible(true);
		gameScreens[GAME_OVER].setVisible(false);
		gameState = TITLE_SCREEN;
				
		gameTimer.stop();
		newGame();
	}
	
	/**
	 * Pause or unpause the game
	 */
	public void pause() {
		if (gameTimer.isPaused()) {
			gameTimer.start();
		}
		else {
			gameTimer.stop();
		}
	}

	//--- launch the program --------------------------------------------------
	public static void main(String[] args) { launch(); }
}
