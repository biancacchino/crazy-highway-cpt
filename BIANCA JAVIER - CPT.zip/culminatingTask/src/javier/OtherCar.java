package javier;

import java.util.Random;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class OtherCar extends Sprite {
	
	
	public static final int BABY = 0;
	public static final int TODDLER = 1; 
	public static final int TEENAGER = 2;
	public static final int BIGBOY = 3;
	

	public static final Image[] OTHER_CARS = {
			new Image("file:resources/images/enemy0.png"),
			new Image("file:resources/images/enemy1.png"),
			new Image("file:resources/images/enemy2.png"),
			new Image("file:resources/images/enemy3.png")
	};

	public static final Image EXPLOSION_PIC = new Image("file:resources/images/explosion.png");

	private ImageView explosion = new ImageView(EXPLOSION_PIC);

	private double deathDelay = 1;
	
	public static final Random RNG = new Random();
	
	static int scoreValue;
	static int points;
	static int score;
	
	private int health;
	static int type;
	
	private boolean isDead = false;
	
	public OtherCar() {
		super();
		
		type = RNG.nextInt(OTHER_CARS.length);
		super.getChildren().add(explosion);
		explosion.setVisible(false);
		explosion.setLayoutX(10);
		explosion.setLayoutY(0);		
		setEnemyType(type);

	}
	
	private void setEnemyType(int type) {
		switch(type) {
		case BABY:
			health = 2;
			break;
		case TODDLER:
			health = 3;
			break;
		case TEENAGER:
			health = 5;
			break;
		case BIGBOY:
			health = 6;
			break;
		default:
			health = 1;
			break;
		}
		setImage(OTHER_CARS[type]);
		
	}


	public void kill() {
		isDead = true;
		explosion.setVisible(true);
		setVelocity(0, 200);
		
	}
    
	public boolean isDead() {
		return isDead;
	}
	
	public void takeDamage() {
		health--;
		if(health <=0) {
			kill();
		}

	}
	public int getType() {
		return type;
	}

	public boolean isReadyForCleanUp() {
		return deathDelay < 0;
	}
	
	public void update(double time) {
		super.update(time);
		if (isDead) {
			deathDelay -= time;
		}
		
	}
	

	
}
